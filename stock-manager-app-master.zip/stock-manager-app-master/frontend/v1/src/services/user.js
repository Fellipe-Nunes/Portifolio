import { clientHttp } from '../config/config.js'

const createUser = (data) => clientHttp.post(`/api/user`, data)

const ListUser = () => clientHttp.get(`/api/user`)

const DeleteUser = (email) => clientHttp.delete(`/api/user/${email}`)

export {
    createUser,
    ListUser,
    DeleteUser
}