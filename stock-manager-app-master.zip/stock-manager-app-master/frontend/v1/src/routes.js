import React from 'react'
import Login from './components/login/login'
import Form from './cadastro/Form'

import {
    BrowserRouter as Router,
    Switch,
    Route
    // Redirect
} from "react-router-dom";


const Routers = () => (
    <Router>
        <Switch>
          
            <Route exact path="/" component={Login} />
            <Route exact path="/form" component={Form} />
            {/* <Route exact path="*" component={() => (<Redirect to="/" />)} /> */}
            <Route exact path="*" component={() => (<h1>404 | Not Found</h1>)} />

        </Switch>
    </Router>
)

export default Routers;
