import axios from 'axios'

const clientHttp = axios.create({
    baseURL: `http://localhost:3002`,
})

clientHttp.defaults.headers['Content-Type'] = 'application/json';

export {
    clientHttp
}