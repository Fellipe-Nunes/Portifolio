# bootcamp-backend-projeto-zero

Primeiro projeto backend do Bootcamp FullStack Infnet.
Api de CRUD de usuários

## Versão

0.1.0 (beta)

## Pre requisitos
* node

## Instalação

``` npm install ```

## Root API

/api/

## TODO

* api POST user

* api GET user

* api GET user/:id

* api PUT user

* api PATCH user

* api DELETE user

* config MONGODB



