import React from 'react';

const Form = () => {
    return (

        <div id="app">


            <div>
                <input type="text" name="nome" placeholder="Insira o produto" />
                <input type="text" name="marca" placeholder="Insira a marca" />
                <input type="text" name="valor" placeholder="Insira o valor" />
                <input type="text" name="quantidade" placeholder="Insira a quantidade" />
                <input type="text" name="descricao" placeholder="Insira a descrição" />
            </div>

            <div>
                <button >Cadastrar</button>
                <button >Voltar</button>
            </div>

            <footer>
                <h3>Projeto 1 Bootcamp - Fellipe Nunes</h3>
            </footer>
        </div>
    )
}


export default Form