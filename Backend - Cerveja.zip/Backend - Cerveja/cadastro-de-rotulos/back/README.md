# Api de cadastro de rotulos

Api para cadastro de rotulos de cervejas

## Versão

0.1.0 (beta)

## Pre requisitos
* node

## Instalação

``` npm install ```

## TODO

* config MONGODB
